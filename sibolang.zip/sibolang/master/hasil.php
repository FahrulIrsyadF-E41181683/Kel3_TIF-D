Ambil dari database yang idnya =
<?php
echo $_POST['rowid'];
?>