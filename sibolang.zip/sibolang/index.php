
<?php echo "<script>document.location.href='home/home1.php';</script>\n"; ?>